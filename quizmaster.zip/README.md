# Installation

1. Clone or extract the repository.
2. Create a database (database name: quizmaster)
3. Import the sql file insde the database_sql_file folder
4. Open the project in integrated terminal and the run php -S localhost:8080
5. Try it yourself
