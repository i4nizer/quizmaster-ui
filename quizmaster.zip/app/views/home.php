<?php include APP_DIR . 'views/templates/head.php'; ?>

<body style="height: 100dvh;">

    <main class="m-0 h-100 bg-light d-flex align-items-center justify-content-center">

        <div class="d-flex flex-column align-items-center justify-content-center gap-3" style="width: 600px;">
            <span class="fs-1 fw-bold">Quiz Master</span>
            <span>Welcome!!!</span>
            <a class="btn-lg btn-primary text-decoration-none" href="/user/quizzes">Create Quizzes</a>
        </div>

    </main>

</body>

</html>